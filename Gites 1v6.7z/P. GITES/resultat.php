<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body class="resultat">
    <header>
        <section class="content">
            <form action="resultat.php" method="post">
                <div class="formReach">
                    <input type="search" id="place" name="place" placeholder="Destination" value="<?= $_POST['place']?>">
                    <label class="case" for="arrive">Arrivée:</label>
                    <input type="date" id="start" name="start" min="<?= date('Y-m-d') ?>">
                    <label class="case" for="departure">Départ:</label>
                    <input type="date" id="leave" name="leave" min="<?= date('Y-m-d') ?>">
                    <div class="button">
                        <button>Rechercher</button>
                    </div>
                </div>
            </form>
        </section>
    </header>

    <main>
        <section class="resultat">
            <div class="lodgeList">
                <?php
                require_once "connect.php";
                require_once "classes/LodgeManager.php";
                require_once "classes/class.lodge.php";

                $manager = new LodgeManager($db);
                $lodge = $manager->getSearch($_POST['place']);

                foreach ($lodge as $data) :
                    echo '<div class="lodgeImg">';
                    foreach (unserialize($data->getImage()) as $image) {
                        echo '<div>';
                        echo '<img src="' . $image . '" alt="" width="50px" height="35">';
                    }
                ?>
                <a href="presentation.php?id= <?=$data->getIdLodge()?> ">
                    <div class="lodge">
                        <h3>Nom du gîte:<?= $data->getlodgename(); ?></h3>
                        <p>Categorie:<?= $data->getCategory(); ?></p>
                        <p>Surface:<?= $data->getSpecificity(); ?></p>
                        <p>Nombre de salle de bain:<?= $data->getBathroom(); ?></p>
                        <p>Nombre de couchage:<?= $data->getBedroom(); 
                        echo '</div>';?></p>
                    </div>
                </a>

            </div>
        <?php endforeach; ?>
        </section>
    </main>
    </body.resultat>

</html>