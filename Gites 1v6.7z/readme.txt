C ok
R ok
U ok
D ok


champ description = ok
Input file multiple au lieu de 4 
Slider page de presentation = ok


Condition d'extension autorisée pour les images
FIltrer resultat de la localisation / preremplir la barre de recherche
